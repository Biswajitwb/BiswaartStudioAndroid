BISWAART STUDIO — PROFESSIONAL ANDROID PROJECT
Version: 2.0 Professional
Theme: Gerua #C65B25 | Emerald #176B45 | Royal Gold #D4AF37 | Cream #F4E9D5 | Charcoal #252D29

এই সংস্করণে রয়েছে:
1. Android WebView app shell এবং Gallery image picker
2. Photo, Bengali/English text এবং 16 ধরনের editable shape
3. Unlimited practical layers (বাস্তব সীমা ডিভাইসের RAM/storage)
4. Layer select, visibility, lock, duplicate, delete, reorder
5. Drag move, position/size/colour/opacity controls
6. Image contextual toolbar: Replace, Opacity, Crop/Fit, Rotate, Flip, Erase, Remove
7. Manual pixel mask Erase/Restore, brush size/opacity/hardness, invert/reset mask
8. Offline colour-key background removal with tolerance; এটি AI subject recognition নয়
9. Brightness, contrast, saturation adjustments
10. A4, Square, Story/Reel, YouTube canvas presets
11. PNG/JPG export to Pictures/Biswaart Studio on Android
12. Local project save/open and JSON backup import/export
13. Undo/Redo foundation

সীমাবদ্ধতা:
- AI background removal, generative fill, AI face retouch এবং cloud sync অন্তর্ভুক্ত নয়; এগুলোর জন্য AI backend/API ও internet integration প্রয়োজন।
- Export image is rendered at the selected canvas resolution. Very large canvases require sufficient device memory.
- Android APK must be built with Java 17, Android SDK 35 and Gradle 8.9.

Mobile cloud build:
1. ZIP extract করুন।
2. GitHub repository root-এ project-এর ভেতরের সব ফাইল upload করুন (.github সহ)।
3. Actions > Build Biswaart Studio APK > Run workflow।
4. সফল হলে Artifacts থেকে Biswaart-Studio-debug-APK ডাউনলোড করুন।
5. ZIP extract করে app-debug.apk install করুন।


VERSION 2.1 STUDIO FOUNDATION UPDATE
- Added Custom Canvas Size with px, in, mm, cm and DPI conversion.
- Added editable text effect controls: Stroke, Shadow, Inner Shadow, Emboss, Perspective, 3D Rotate, 3D Text and 3D Shadow.
- Added live canvas preview for text effects.
- Added .biswa editable project backup format and automatic local project saving.
- PSD import/export and advanced AI background removal are not yet implemented in this build.
